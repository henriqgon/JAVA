package com.mycompany.prjinterfaces.classes;

/**
 *
 * @author IFTM
 */
public class GerarExtratos {
    public void geradorExtratoConta(Conta conta){
        System.out.println("Saldo Atual: " + conta.getSaldo());
    }
}
